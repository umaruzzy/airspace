import React from "react";
import { estate_home2, estate_sky } from "../assets/images";
import { PiAlarm, PiLock, PiWarehouse } from "react-icons/pi";

export default function Home() {
  return (
    <>
      <main className=" flex flex-col bg-white p-4">
        <section className="container mx-auto flex flex-col md:flex-row-reverse gap-4 md:items-center md:gap-8">
          <aside className="flex-1 relative h-72 md:h-full w-full rounded-lg overflow-hidden min-h-[288px] md:min-h-[600px]">
            <img
              src={estate_home2}
              alt=""
              className="absolute h-full w-full top-0 left-0 object-cover"
            />
          </aside>
          <aside className="flex-1 flex flex-col gap-3 py-5 md:py-10  ">
            <h2 className="text-slate-800 font-bold text-2xl sm:text-3xl md:text-5xl leading-snug">
              Airspace is on a Mission to Change the View of Real Estate
            </h2>
            <p className="text-slate-700 text-base sm:text-lg text-justify leading-relaxed">
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorum
              eaque quod libero? Quam, quas deleniti quis tempora unde labore
              ipsa debitis tenetur necessitatibus cupiditate, porro eveniet
              consectetur veritatis quo reiciendis.
            </p>
            <div className="bg-white hover:drop-shadow-2xl mt-4 rounded-md p-4 flex items-center gap-4 ">
              <div className="flex-shrink-0 h-8 md:h-12 w-8 md:w-12 rounded-full grid place-items-center bg-orange-500 text-slate-800 text-2xl md:text-3xl">
                <PiWarehouse />
              </div>
              <div className="flex flex-col">
                <h4 className="text-slate-800 font-semibold text-xlg md:text-2xl">
                  Modern Villa
                </h4>
                <p className="text-slate-700 text-xs sm:text-sm text-justify leading-relaxed">
                  Lorem ipsum dolor sit amet consectetur adipisicing elit. Iure
                  sed quod minus facilis. Placeat, cum?
                </p>
              </div>
            </div>
            <div className="bg-white hover:drop-shadow-2xl mt-4 rounded-md p-4 flex items-center gap-4">
              <div className="flex-shrink-0 h-8 md:h-12 w-8 md:w-12 rounded-full grid place-items-center bg-orange-500 text-slate-800 text-2xl md:text-3xl">
                <PiLock />
              </div>
              <div className="flex flex-col">
                <h4 className="text-slate-800 font-semibold text-xlg md:text-2xl">
                  Secure Payment
                </h4>
                <p className="text-slate-700 text-xs sm:text-sm text-justify leading-relaxed">
                  Lorem ipsum dolor sit amet consectetur adipisicing elit. Iure
                  sed quod minus facilis. Placeat, cum?
                </p>
              </div>
            </div>
          </aside>
        </section>
      </main>
    </>
  );
}
